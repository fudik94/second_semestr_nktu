


from math_operations import add
from math_operations import random_sqrt_sum #Import add() from math_operations.py.
import random
from math_operations import multiply

num_1=random.randint(1, 100) #generate two random numbers
num_2=random.randint(1, 100)

result_add=add(15,6)
result_random_sqrt_sum=random_sqrt_sum() #Use it with random_sqrt_sum() to demonstrate modular functionality.

result_multiply=multiply(num_1,num_2) #apply multiply()

finall_result=add(result_multiply,result_random_sqrt_sum) #use add() to combine the result with random_sqrt_sum()

print(f'Its result add: {result_add}')
print(f'Its result random_sqrt_sum :{result_random_sqrt_sum}')

print("Bonus Challenge:")

print(f'Final result: {finall_result}')









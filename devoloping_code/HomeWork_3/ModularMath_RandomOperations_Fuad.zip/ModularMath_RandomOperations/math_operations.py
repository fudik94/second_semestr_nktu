

import math as m  #Import math as m and random
import random

def add(a, b): #Implement add(a, b)
    return a+b

def multiply(a, b): #multiply(a, b)
    return a*b

def random_sqrt_sum(): #generates a random integer between 1 and 100 and adds its square root to itself
    a=random.randint(1, 100)
    a1=m.sqrt(a)

    return a+a1


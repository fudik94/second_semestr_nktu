"""geometry.py: Implement circle_area(radius) to return the area of a circle."""

import math

def circle_area(radius):
    return math.pi *radius**2
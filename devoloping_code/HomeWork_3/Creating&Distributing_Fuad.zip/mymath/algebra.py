"""algebra.py: Implement solve_quadratic(a, b, c) 
to return the roots of a quadratic equation (ax² + bx + c = 0)."""


import math


def solve_quadratic(a, b, c):
    D = b**2 - 4*a*c

    if D < 0:
        return "Smth wrong" 
    
    if D == 0:
        return  -b / (2 * a)
    
    sqrt_D = math.sqrt(D)
    return (-b + sqrt_D) /(2 * a), (-b - sqrt_D) / (2 * a)
      